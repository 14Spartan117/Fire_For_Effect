"""
Generate architecture.png — no overlapping boxes.
"""
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch

FW, FH = 34, 22
fig, ax = plt.subplots(figsize=(FW, FH), dpi=150)
BG = "#0d1117"
fig.patch.set_facecolor(BG)
ax.set_facecolor(BG)
ax.set_xlim(0, FW)
ax.set_ylim(0, FH)
ax.axis("off")

CARD   = "#161b22"
BORDER = "#30363d"
TEXT   = "#e6edf3"
DIM    = "#8b949e"
CODE   = "#c9d1d9"
GREEN  = "#3fb950"
PURPLE = "#bc8cff"
BLUE   = "#58a6ff"
YELLOW = "#e3b341"
RED    = "#f85149"
TEAL   = "#39d353"


def card(x, y, w, h, title, lines, accent, title_sz=8.5, line_sz=6.5):
    # shadow
    ax.add_patch(FancyBboxPatch(
        (x + 0.09, y - 0.09), w, h,
        boxstyle="round,pad=0.1", linewidth=0,
        facecolor="#000000", alpha=0.45, zorder=1))
    # body
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.1", linewidth=1,
        edgecolor=BORDER, facecolor=CARD, zorder=2))
    # accent bar
    bh = 0.33
    ax.add_patch(FancyBboxPatch(
        (x, y + h - bh), w, bh,
        boxstyle="square,pad=0", linewidth=0,
        facecolor=accent, alpha=0.88, zorder=3))
    # title
    ax.text(x + w / 2, y + h - bh / 2, title,
            ha="center", va="center", color="white",
            fontsize=title_sz, fontweight="bold",
            fontfamily="monospace", zorder=4)
    # content lines
    ly = y + h - bh - 0.24
    for line in lines:
        ax.text(x + 0.18, ly, line,
                ha="left", va="top", color=CODE,
                fontsize=line_sz, fontfamily="monospace", zorder=4)
        ly -= 0.27


def sec_label(x, y, label, color):
    ax.plot([x, x + 33.0], [y, y], color=color, lw=1.0, alpha=0.35, zorder=2)
    ax.text(x + 0.15, y + 0.07, label,
            ha="left", va="bottom", color=color,
            fontsize=8.5, fontweight="bold", fontfamily="sans-serif", zorder=3)


def arr(x1, y1, x2, y2, color=BLUE, lbl="", rad=0.0):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(
                    arrowstyle="-|>", color=color, lw=1.3,
                    connectionstyle=f"arc3,rad={rad}"),
                zorder=8)
    if lbl:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        ax.text(mx + 0.1, my + 0.08, lbl,
                ha="center", va="bottom", color=color,
                fontsize=5.5, fontfamily="monospace", zorder=9)


# ── Title bar ─────────────────────────────────────────────────────────────────
ax.add_patch(FancyBboxPatch((0, 20.8), FW, 1.2,
    boxstyle="square,pad=0", linewidth=0, facecolor="#161b22", zorder=1))
ax.plot([0, FW], [20.8, 20.8], color=RED, lw=2.5, zorder=3)
ax.text(FW / 2, 21.45, "F.I.R.E. for Effect",
        ha="center", va="center", color=TEXT,
        fontsize=24, fontweight="bold", fontfamily="sans-serif")
ax.text(FW / 2, 21.06,
        "Project Architecture  \u00b7  Streamlit  \u00b7  Python 3.11"
        "  \u00b7  yfinance  \u00b7  fpdf2  \u00b7  Google Sheets",
        ha="center", va="center", color=DIM,
        fontsize=9, fontfamily="sans-serif")

# ── Section: Infrastructure  (y 17.5 \u2013 20.3) ─────────────────────────────────
sec_label(0.5, 20.55, "\u2500\u2500 INFRASTRUCTURE", YELLOW)

card(0.5,  17.5, 8.5, 2.8, "config.py",
     ["FUND_NOMINAL_RATES   C:11.3%  S:9.4%  I:6.3%  F:5.4%  G:4.7%",
      "PROMOTION_TIMELINE   E-1:0yr  \u2192  O-7:31yr",
      "PROGRESSION chains   enlisted / officer / warrant",
      "BAS_ENLISTED=$515   BAS_OFFICER=$360",
      "SHEET_ID  (Google Sheets analytics target)"],
     YELLOW)

card(9.5,  17.5, 8.5, 2.8, "data/loader.py",
     ["load_military_data()  \u2192  military_data.json",
      "get_base_pay(rank, tis) \u2192 float",
      "get_bah_rate(mha, rank, dep_status) \u2192 float",
      "get_bas(rank_type) \u2192 float",
      "@st.cache_data  |  Path(__file__) anchored"],
     GREEN)

card(18.5, 17.5, 8.5, 2.8, "analytics/tracking.py",
     ["get_anon_id()    SHA-256 fingerprint  (no PII stored)",
      "get_device_type()  \u2192 mobile | desktop",
      "log_session()    \u2192 gspread \u2192 Google Sheets",
      "Fires once on PDF download  (Tab 7 trigger)",
      "consent_given flag gates all logging calls"],
     YELLOW)

# ── Section: Models  (y 12.2 \u2013 17.0) ─────────────────────────────────────────
sec_label(0.5, 17.35, "\u2500\u2500 MODELS", PURPLE)

MX = [0.5, 7.0, 13.5, 20.0]
MW = 6.2
MH = 4.8
MY = 12.2

card(MX[0], MY, MW, MH, "models/allocations.py",
     ["get_lifecycle_allocation(yrs_to_retire)",
      "  >20yr: C70%  S20%  I10%",
      "  >10yr: C40%  S15%  I15%  F20%  G10%",
      "  > 0yr: C20%  S5%   I5%   F30%  G40%",
      "  <=0yr: F30%  G70%",
      "",
      "get_blended_nominal_return(alloc, yrs)",
      "get_time_weighted_blended_return(alloc, mo)",
      "  \u2190 glide-path-aware  (solver alignment)"],
     PURPLE)

card(MX[1], MY, MW, MH, "models/projections.py",
     ["get_progression_chain(rank)",
      "  \u2192 enlisted / officer / warrant chain",
      "",
      "build_monthly_base_pay_schedule()",
      "  \u2192 income[] simulating promotions",
      "",
      "solve_savings_rate(target, income[], r, mo)",
      "  \u2192 PMT solver",
      "  \u2192 required $/month to hit FIRE number"],
     PURPLE)

card(MX[2], MY, MW, MH, "models/pension.py",
     ["calc_high3_pension(",
      "  retire_rank, yrs_at_retire, multiplier",
      ")",
      "",
      "avg(base_pay at yrs\u22123, yrs\u22122, yrs\u22121)",
      "  \u00d7 years_of_service \u00d7 multiplier",
      "",
      "Uses PROMOTION_TIMELINE to determine",
      "actual rank held in each lookback year"],
     PURPLE)

card(MX[3], MY, MW, MH, "models/monte_carlo.py",
     ["scrape_and_prep_tsp_data()  @cache 24h",
      "  1. TSP.gov  (primary \u2014 often returns 403)",
      "  2. yfinance ETF proxies  (fallback)",
      "     C\u2192SPY   S\u2192VXF   I\u2192EFA",
      "     F\u2192AGG   G\u2192SHY",
      "",
      "run_real_monte_carlo(",
      "  age, retire_age, bal, contrib[],",
      "  hist_returns, alloc, inflation)",
      "  1,000 bootstrap trials \u2192 percentile bands"],
     PURPLE)

# External data  (same y band as models, right column)
card(27.5, MY, 6.0, MH, "External Data Sources",
     ["TSP.gov  (primary)",
      "  /data/fund-performance",
      "  \u26a0  Blocks automated requests (HTTP 403)",
      "",
      "yfinance  (fallback)",
      "  SPY  VXF  EFA  AGG  SHY",
      "  Since 2003-11-01  (AGG launch date)",
      "  Monthly close \u2192 pct_change()",
      "  @st.cache_data  ttl=86400s"],
     TEAL, title_sz=8.5)

# arrow: monte_carlo \u2194 external data
arr(26.2, 14.9, 27.4, 14.9, TEAL, "fetch / return")

# ── Section: Session State  (y 9.5 \u2013 11.8) ──────────────────────────────────
sec_label(0.5, 12.05, "\u2500\u2500 STREAMLIT SESSION STATE  (Shared Data Bus)", RED)

ax.add_patch(FancyBboxPatch((0.5, 9.5), 33.0, 2.3,
    boxstyle="round,pad=0.12", linewidth=1.5,
    edgecolor=RED, facecolor="#160c0c", alpha=0.95, zorder=2))

ax.text(0.85, 11.6, "Financial Keys",
        color=RED, fontsize=8, fontweight="bold",
        fontfamily="monospace", va="top", zorder=4)
ax.text(0.85, 11.28,
        "base_pay  bah_amt  bas_amt  special_pay  tab1_rank  tab1_tis\n"
        "pmt_target  savings_rate_pct  nest_egg_target  est_pension  mc_success_rate\n"
        "tab3_take_home  tab3_fixed  tab3_invested  tab3_guilt_free  les_tsp_actual  bah_manual",
        color=CODE, fontsize=6.5, fontfamily="monospace",
        va="top", linespacing=1.6, zorder=4)

ax.text(17.5, 11.6, "Analytics Keys",
        color=YELLOW, fontsize=8, fontweight="bold",
        fontfamily="monospace", va="top", zorder=4)
ax.text(17.5, 11.28,
        "consent_given  session_start  anon_id  device_type\n"
        "tabs_visited  max_tab_reached  tracked_zip  monte_carlo_run\n"
        "quiz_score  pdf_downloaded  last_error  session_logged",
        color=CODE, fontsize=6.5, fontfamily="monospace",
        va="top", linespacing=1.6, zorder=4)

# arrows: models \u2192 session state top (y=11.8)
for mx in [MX[0] + MW / 2, MX[1] + MW / 2, MX[2] + MW / 2, MX[3] + MW / 2]:
    arr(mx, MY, mx, 11.8, PURPLE)

# ── app.py entry point  (y 8.7 \u2013 9.3) ──────────────────────────────────────
ax.add_patch(FancyBboxPatch((8.5, 8.7), 17.0, 0.62,
    boxstyle="round,pad=0.08", linewidth=1.5,
    edgecolor=RED, facecolor="#2a0d0d", zorder=3))
ax.text(17.0, 9.01,
        "\u25b6  app.py  \u2014  Entry Point  |  init_session_state()  "
        "|  st.tabs([Tab1\u2026Tab7])  |  render_tab_*()",
        ha="center", va="center", color=TEXT,
        fontsize=8.5, fontweight="bold", fontfamily="monospace", zorder=4)

# arrows around app.py
arr(17.0, 9.5,  17.0, 9.32, RED)   # session state \u2192 app.py
arr(17.0, 8.7,  17.0, 8.55, RED)   # app.py \u2192 tabs

# ── Section: UI Layer ─────────────────────────────────────────────────────────
sec_label(0.5, 8.57, "\u2500\u2500 UI LAYER", BLUE)

TW = 7.5
TX = [0.5, 8.5, 16.5, 24.5]

# Row 1 of tabs  (y 5.7 \u2013 8.45)
TY1 = 5.7
TH1 = 2.7

card(TX[0], TY1, TW, TH1, "Tab 1 \u00b7 tab_income.py",
     ["Rank + TIS selectors",
      "BAH  zip code \u2192 MHA lookup",
      "BAS  enlisted / officer lookup",
      "Special pays entry",
      "\u2192 ss.base_pay  ss.bah_amt  ss.bas_amt",
      "\u2192 ss.tab1_rank  ss.tab1_tis"],
     BLUE)

card(TX[1], TY1, TW, TH1, "Tab 2 \u00b7 tab_retirement.py",
     ["FIRE solver  (PMT-based)",
      "High-3 pension estimator",
      "Monte Carlo 1,000-trial chart",
      "Savings rate explorer slider",
      "\u2192 ss.pmt_target  ss.est_pension",
      "\u2192 ss.nest_egg_target  ss.mc_success_rate"],
     BLUE)

card(TX[2], TY1, TW, TH1, "Tab 3 \u00b7 tab_budget.py",
     ["LES mode vs \U0001f3b2 Algorithm mode",
      "Fixed / Invested / Guilt-Free buckets",
      "Federal + FICA tax estimator",
      "Sankey cash-flow chart  (Plotly)",
      "\u2192 ss.tab3_take_home  ss.tab3_fixed",
      "\u2192 ss.tab3_invested   ss.tab3_guilt_free"],
     BLUE)

card(TX[3], TY1, TW, TH1, "Tab 4 \u00b7 tab_quiz.py",
     ["Financial literacy quiz",
      "8 scored questions",
      "Instant per-question feedback",
      "\u2192 ss.quiz_score"],
     BLUE)

# Row 2 of tabs  (y 2.5 \u2013 5.4)
TY2 = 2.5
TH2 = 2.9

card(TX[0], TY2, TW, TH2, "Tab 5 \u00b7 tab_action.py",
     ["Way Ahead: Order of Operations",
      "9-step gamified checklist",
      "BRS match / SCRA / HYSA / TSP",
      "GI Bill transfer / SDP / VA Loan",
      "Mission completion progress bar"],
     BLUE)

card(TX[1], TY2, TW, TH2, "Tab 6 \u00b7 tab_feedback.py",
     ["User feedback form",
      "Free-text input",
      "Submitted to Google Sheets via gspread"],
     BLUE)

card(TX[2], TY2, TW, TH2, "Tab 7 \u00b7 tab_plan.py",
     ["Snapshot: income + retirement + budget",
      "On-track vs shortfall assessment",
      "PDF generation  (fpdf2)",
      "Priority action list in PDF",
      "\u2192 triggers log_session() on download",
      "\u2192 ss.pdf_downloaded = True"],
     BLUE)

card(TX[3], TY2, TW, TH2, "ui/state.py  +  consent.py",
     ["init_session_state()  \u2014 sets all defaults",
      "consent.py  \u2014 opt-in analytics gate",
      "__init__.py  \u2014 re-exports render fns",
      "Seeded before any tab renders"],
     BLUE)

# ── Legend ────────────────────────────────────────────────────────────────────
legend_items = [
    (YELLOW, "Config / Analytics"),
    (GREEN,  "Data Layer"),
    (PURPLE, "Models Layer"),
    (TEAL,   "External Data"),
    (BLUE,   "UI Layer"),
    (RED,    "Entry / Session State"),
]
lx, ly = 29.2, 8.45
ax.text(lx, ly + 0.14, "LEGEND",
        color=DIM, fontsize=8.5, fontweight="bold",
        fontfamily="sans-serif", va="bottom")
for i, (color, label) in enumerate(legend_items):
    yy = ly - i * 0.33
    ax.add_patch(mpatches.Circle((lx + 0.16, yy), 0.11, color=color, zorder=5))
    ax.text(lx + 0.42, yy, label, va="center",
            color=DIM, fontsize=7.5, fontfamily="sans-serif")

# ── Footer ────────────────────────────────────────────────────────────────────
ax.text(FW / 2, 0.22,
        "No user data is stored server-side per browser session  \u00b7  "
        "Analytics use anonymous session IDs only  \u00b7  For educational use",
        ha="center", va="bottom", color=DIM,
        fontsize=7.5, fontfamily="sans-serif")

plt.tight_layout(pad=0)
plt.savefig(
    "/Users/brandondelarosa/Downloads/GITLAB/fire_for_effect/architecture.png",
    dpi=150, bbox_inches="tight", facecolor=BG)
plt.close()
print("Done.")
