"""
TSP historical-return scraper and Monte Carlo retirement simulator.
"""

import io

import numpy as np
import pandas as pd
import requests
import streamlit as st
import yfinance as yf

from models.allocations import get_lifecycle_allocation


# ── ETF proxies for TSP funds ─────────────────────────────────────────────────
# C: SPY  (SPDR S&P 500)           → C Fund tracks S&P 500
# S: VXF  (Vanguard Extended Mkt)  → S Fund tracks DJ US Completion TSM
# I: EFA  (iShares MSCI EAFE)      → I Fund tracks MSCI EAFE
# F: AGG  (iShares US Agg Bond)    → F Fund tracks Bloomberg US Agg Bond
# G: SHY  (iShares 1-3yr Treasury) → G Fund proxy (no market equivalent)
_FUND_TICKERS = {"C": "SPY", "S": "VXF", "I": "EFA", "F": "AGG", "G": "SHY"}
_ETF_START = "2003-11-01"  # AGG launch date — earliest common history


def _yfinance_returns() -> pd.DataFrame:
    """Download real ETF monthly returns as TSP fund proxies."""
    tickers = list(_FUND_TICKERS.values())
    raw = yf.download(tickers, start=_ETF_START, auto_adjust=True, progress=False)
    prices = raw["Close"].rename(columns={v: k for k, v in _FUND_TICKERS.items()})
    monthly = prices.resample("ME").last()
    returns = monthly.pct_change()
    returns.replace([np.inf, -np.inf], np.nan, inplace=True)
    returns = returns.dropna()
    return returns[["C", "S", "I", "F", "G"]]


# ── Data loader ───────────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False, ttl=86400)
def scrape_and_prep_tsp_data():
    """
    Fetch real TSP fund return data.  Tries TSP.gov first; falls back to
    yfinance ETF proxies (real historical data).  Returns
    (monthly_returns_df, source_label).  Raises on total failure.
    """
    # ── 1. Try TSP.gov direct ─────────────────────────────────────────────────
    url = "https://www.tsp.gov/data/fund-price-history.csv"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "text/csv,application/csv",
        "Referer": "https://www.tsp.gov/",
    }
    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        if "<html" in response.text.lower() or "<!doctype html" in response.text.lower():
            raise ValueError("TSP.gov returned HTML (blocked).")

        df = pd.read_csv(io.StringIO(response.text))
        df.columns = df.columns.str.strip().str.lower()
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values("date").set_index("date")

        core = []
        for fund in ["c", "s", "i", "f", "g"]:
            if fund in df.columns:
                core.append(fund)
            elif f"{fund} fund" in df.columns:
                df.rename(columns={f"{fund} fund": fund}, inplace=True)
                core.append(fund)

        for col in core:
            if df[col].dtype == object:
                df[col] = df[col].astype(str).str.replace(",", "").astype(float)

        monthly = df[core].resample("ME").last().pct_change()
        monthly.replace([np.inf, -np.inf], np.nan, inplace=True)
        monthly = monthly.dropna()
        monthly.columns = ["C", "S", "I", "F", "G"]
        return monthly, "TSP.gov (Live)"

    except Exception:
        pass

    # ── 2. Fall back to real ETF proxies via yfinance ─────────────────────────
    try:
        returns = _yfinance_returns()
        if returns.empty:
            raise ValueError("yfinance returned no data.")
        return returns, "ETF Proxy (Real)"
    except Exception as exc:
        raise RuntimeError(
            "Could not load TSP data from TSP.gov or yfinance. "
            "Check your internet connection."
        ) from exc


# ── Monte Carlo engine ───────────────────────────────────────────────────────

def run_real_monte_carlo(
    current_age: int,
    retire_age: int,
    initial_bal: float,
    monthly_contrib,
    hist_returns: pd.DataFrame,
    use_lc: bool,
    manual_alloc: dict,
    inflation_rate: float = 0.025,
    trials: int = 1000,
) -> np.ndarray:
    """
    Run *trials* bootstrap Monte Carlo simulations.

    monthly_contrib can be a scalar (fixed $) or list/array of length *months*.
    Returns an (trials x months+1) numpy array of portfolio paths.
    """
    months = (retire_age - current_age) * 12
    monthly_inflation = (1 + inflation_rate) ** (1 / 12) - 1

    if np.isscalar(monthly_contrib):
        contrib_schedule = np.full(months, monthly_contrib)
    else:
        contrib_schedule = np.array(monthly_contrib)
        if len(contrib_schedule) < months:
            contrib_schedule = np.pad(
                contrib_schedule, (0, months - len(contrib_schedule)), "edge"
            )
        else:
            contrib_schedule = contrib_schedule[:months]

    results = []
    for _ in range(trials):
        balance = initial_bal
        path = [balance]
        samples = hist_returns.sample(months, replace=True)

        for i in range(months):
            if use_lc:
                years_left = (months - i) / 12
                alloc = get_lifecycle_allocation(years_left)
            else:
                alloc = manual_alloc

            nom_ret = sum(samples.iloc[i][f] * alloc.get(f, 0) for f in alloc)
            real_ret = (1 + nom_ret) / (1 + monthly_inflation) - 1
            balance = (balance * (1 + real_ret)) + contrib_schedule[i]
            path.append(balance)

        results.append(path)
    return np.array(results)
